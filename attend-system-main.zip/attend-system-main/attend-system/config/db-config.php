<?php
	$host  = 'localhost';
    $user  = 'root';
    $password   = "";
    $database  = "attendance_system"; 
    $dbc = mysqli_connect($host,$user,$password,$database);
?>