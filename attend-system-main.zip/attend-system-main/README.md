# attend-system
usign, html, css, js, ajax and php with mysql

-*************************************************
Following Steps:
Step 1:
first download zip file then extract file 
Step 2:
goto youer xampp\htdocs folder then paste extract file
Step 3:
open http://localhost/phpmyadmin 
Step 4:
create new Databse 
Database name: "attendance_system"
Step 5:
then import '.Sql' file
then last open your browser and type.. 
http://localhost/attend-system

******show login page******* 

Admin:
admin123@gmail.com
Pass: 123
*************************
Teacher:
nayaldaksh@gmail.com
Pass: 123
****************************
Student:
kalyani123@gmail.com
Pass: 123
***************************


Please Visit my site
http://hack2009gitroshan.rf.gd/index.php
